// Roda no mundo principal (MAIN world) — acessa React fiber do WA Web
window.__livecrm_extractor_loaded = true;
console.log('[LiveCRM Extractor] phone_extractor.js carregado');
(function () {
  let lastPhone = null;

  function extractJid(v) {
    if (!v) return null;
    if (typeof v === 'string' && v.includes('@c.us')) return v.replace(/@c\.us.*/, '');
    if (typeof v === 'object') {
      const candidates = [v._serialized, v.jid, v.user && v.server === 'c.us' ? v.user : null];
      for (const c of candidates) {
        if (typeof c === 'string' && c.includes('@c.us')) return c.replace(/@c\.us.*/, '');
      }
    }
    return null;
  }

  function searchProps(props) {
    if (!props) return null;
    // Props diretas com JID
    for (const k of ['jid', 'id', 'chatId', 'phone', 'waId']) {
      const p = extractJid(props[k]);
      if (p) return p;
    }
    // Objetos aninhados comuns no WA Web
    for (const k of ['chat', 'contact', 'peer', 'to', 'from', 'metadata']) {
      const obj = props[k];
      if (!obj || typeof obj !== 'object' || Array.isArray(obj)) continue;
      const p =
        extractJid(obj.id) ||
        extractJid(obj.jid) ||
        extractJid(obj._serialized) ||
        extractJid(obj.id && typeof obj.id === 'object' ? obj.id._serialized : null) ||
        (obj.id?.user && obj.id?.server === 'c.us' ? obj.id.user : null);
      if (p) return p;
    }
    return null;
  }

  function getActivePhone() {
    const el = document.querySelector('[aria-selected="true"]');
    if (!el) return null;

    // Tenta props diretas do elemento
    const propsKey = Object.keys(el).find(k => k.startsWith('__reactProps'));
    if (propsKey) {
      const p = searchProps(el[propsKey]);
      if (p) return p;
    }

    // Sobe pelo fiber tree
    const fiberKey = Object.keys(el).find(k => k.startsWith('__reactFiber'));
    if (!fiberKey) return null;

    let fiber = el[fiberKey];
    let depth = 0;
    while (fiber && depth < 80) {
      const p = searchProps(fiber.memoizedProps);
      if (p) return p;
      // Checa também stateNode se for um componente de classe
      if (fiber.stateNode && typeof fiber.stateNode === 'object') {
        const sp = searchProps(fiber.stateNode.props);
        if (sp) return sp;
      }
      fiber = fiber.return;
      depth++;
    }

    return null;
  }

  function broadcast() {
    const phone = getActivePhone();
    if (phone !== lastPhone) {
      lastPhone = phone;
      window.postMessage({ type: 'LIVECRM_ACTIVE_PHONE', phone }, '*');
      if (phone) console.log('[LiveCRM Extractor] conversa ativa:', phone);
    }
  }

  // Observa mudanças de aria-selected e novas conversas abertas
  new MutationObserver((mutations) => {
    let changed = false;
    for (const m of mutations) {
      if (m.type === 'attributes' && m.attributeName === 'aria-selected') {
        changed = true;
        break;
      }
      if (m.type === 'childList') {
        for (const n of [...m.addedNodes, ...m.removedNodes]) {
          if (n.nodeType === 1 && (n.getAttribute?.('aria-selected') !== null || n.querySelector?.('[aria-selected]'))) {
            changed = true;
            break;
          }
        }
      }
      if (changed) break;
    }
    if (changed) setTimeout(broadcast, 150);
  }).observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['aria-selected'],
  });

  broadcast();
  console.log('[LiveCRM Extractor] iniciado no mundo principal');
})();
